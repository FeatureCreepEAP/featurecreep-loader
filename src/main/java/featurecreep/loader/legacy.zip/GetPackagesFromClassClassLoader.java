package featurecreep.loader;

import java.util.ArrayList;
import java.util.List;

//import javassist.CannotCompileException;
//import javassist.ClassPool;
//import javassist.CtClass;
//import javassist.CtMethod;
//import javassist.CtNewMethod;
//import javassist.NotFoundException;
//import mx.kenzie.mirror.Mirror;

public class GetPackagesFromClassClassLoader {

  public static String[] getPacakgesFromClassLoaderClassAsStringArray(Class clazz) {

    String[] packages_needed;

    List < String > package_list = new ArrayList();

    if (clazz.getClassLoader().equals(GetPackagesFromClassClassLoader.class.getClassLoader()))
      for (int j = 0; j < Package.getPackages().length; j++) {

        package_list.add(Package.getPackages()[j].getName().toString().replace(".", "/"));

      }
    else { //Gotta find a way to do this within pure java
     /* ClassPool pool = ClassPool.getDefault();
      try {
        CtClass cc = pool.get(clazz.getCanonicalName() + "$PackageGetter");
        cc.defrost();
        CtMethod m = CtNewMethod.make(
          "public static Package[] getPackages() {}",
          cc);
        m.insertAfter("return Package.getPackages();");
        Class subclazz = pool.toClass(cc, clazz.getClassLoader());
        Package[] packages = (Package[]) Mirror.of(subclazz).unsafe().method("getPackages", null).invoke();

        for (int p = 0; p < packages.length; p++) {

          package_list.add(packages[p].getName().toString().replace(".", "/"));

        }

      } catch (NotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      } catch (CannotCompileException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
*/
    }

    packages_needed = package_list.toArray(new String[package_list.size()]);

    for (int p = 0; p < packages_needed.length; p++) {

      System.out.println(packages_needed[p]);

    }

    return packages_needed;

  }

}
